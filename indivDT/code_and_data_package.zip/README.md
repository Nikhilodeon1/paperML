# Code and Data Package — anonymous submission

This package contains the code needed to reproduce every number, table, and figure reported in
the paper. It is a subset of a larger private research codebase: only the differentiable
glucose-insulin simulator, the four inference methods (gradient, grid, random forest, SNPE), and
the evaluation/analysis scripts that produce the paper's results are included. Unrelated modules
from the broader research codebase (other physiological subsystems, an orchestration/LLM layer, a
REST API) are not part of any claim in the paper and have been left out.

## Environment

Python 3.14, CPU only (no GPU required at this problem size — all fits are per-subject, 45-97
subjects).

```bash
python -m venv .venv
.venv/Scripts/activate        # or source .venv/bin/activate on Linux/Mac
python -m pip install -r requirements-paper.txt
```

All random seeds are fixed to 42 (`paper_config.py`, `cfg.set_all_seeds()`), so every script below
reproduces the same numbers reported in the paper on repeated runs.

## Data

None of the three datasets are redistributed in this package — all three are public but require
going to the original source (two are credentialed/registration-gated, not a licensing
restriction on our end):

- **CGMacros** (PhysioNet) → place under `data/physionet.org/files/...` (sibling of this package's
  parent directory; see `evaluation/cgmacros.py`'s `_ZIP` path for the exact expected layout).
- **ShanghaiT2DM** (figshare, Zhao et al. 2023) → `data/diabetes_datasets/`
  (`evaluation/shanghai_loader.py`).
- **Hall 2018** (PLOS Biology supplementary files s014.db/s015.tsv/s016.tsv) →
  `data/hall2018/` (`evaluation/hall_loader.py`).

All three loader paths are relative to this package's location (`Path(__file__).resolve()`-based),
not hardcoded — set the `data/` directory alongside wherever you place this package, matching the
structure above, or edit the `_DIR`/`_ZIP` constants at the top of the three loader files.

## Reproducing the paper's results

**One command covers most of the pipeline:**

```bash
python -m evaluation.reproduce_all          # full pipeline, ~3-4 hours
python -m evaluation.reproduce_all --quick  # smaller n, smoke-test the pipeline
```

This regenerates the SBC calibration check, the CGMacros clinical-recovery and held-out-utility
tables, the OOD/simulator-reality-gap analysis, the identifiability analysis, the inference-cost
table, the model-expressiveness/error-decomposition analysis, the Shanghai cross-dataset
validation and tautology check, the gradient-inference results (Table 1's gradient column, Figure
1), the Dalla Man validation gates, the Dalla Man head-to-head comparison, and all committed
figures.

**Four results are not yet wired into `reproduce_all` and must be run individually** (each is
independently reproducible with the same fixed seed; this is a known gap between the pipeline and
the full paper, not a missing capability):

```bash
python -m evaluation.hall_validation          # Table: Hall 2018 external cohort (Si vs HbA1c/SSPG)
python -m evaluation.peaktime_kfold           # Table: peak-timing aligned 5-fold comparison
python -m evaluation.unified_kfold --methods gradient,grid,rf,snpe   # Table 2 (aligned iAUC MAE)
python -m evaluation.fisher_information       # Fisher-information identifiability grounding
```

Other standalone checks referenced in the paper:

```bash
python -m evaluation.dalla_man_comparison --parity   # parity-adjusted Dalla Man vs grid vs bergman
python -m evaluation.carb_sensitivity                # carb-estimation-error robustness check
python -m evaluation.gradient_robustness              # within-cohort subgroup robustness
python -m evaluation.baselines --estimator snpe       # demographic confound check (SNPE Si)
```

(The demographic confound check in `evaluation/baselines.py` defaults to `--estimator snpe`, which
only supports `grid`/`rf`/`snpe`; it does not support `gradient`. The paper's gradient-specific
demographic partial correlation was obtained by feeding `evaluation.gradient_inference_results`'s
per-subject Si into the same OLS/partial-correlation routine — not included as a committed script
in this package, since it is a five-line reuse of already-committed functions, but reconstructible
directly from `evaluation/baselines.py`'s `_ols_predict`/`partial_corr` and
`evaluation/gradient_inference_results.py`'s `collect()`.)

## Table/figure → script map

| Paper item | Script |
|---|---|
| Fig. 1 (gradient-norm identifiability, Bergman) | `evaluation/gradient_inference_results.py` + `figures.py::fig_gradient_identifiability` |
| Fig. 2 (CGMacros clinical recovery) | `evaluation/clinical_recovery.py` + `figures.py::fig_clinical_recovery` |
| Fig. 3 (held-out iAUC MAE by method) | `evaluation/unified_kfold.py` + `figures.py::fig_kfold_utility` |
| Fig. 4 (RF shrinkage vs. SNPE posterior width) | `evaluation/identifiability_analysis.py` + `figures.py::fig_rf_vs_snpe` |
| Fig. 5 (Dalla Man identifiability) | `evaluation/dalla_man_comparison.py` + `figures.py::fig_dalla_man_identifiability` |
| Table 1 (identifiability ratios) | `evaluation/gradient_inference_results.py`, `cross_dataset_validation.py`, `hall_validation.py`, `fisher_information.py` |
| Table 2 (aligned 5-fold iAUC MAE) | `evaluation/unified_kfold.py` |
| Table 3 (error decomposition) | `evaluation/model_expressiveness_analysis.py` |
| Table 4 (clinical recovery, 3 cohorts) | `evaluation/clinical_recovery.py`, `cross_dataset_validation.py`, `hall_validation.py` |
| Peak-timing result (Section 4.4) | `evaluation/peaktime_kfold.py` |
| SNPE feature-leakage / tautology check (Section 4.6) | `evaluation/tautology_check.py` |
| SBC calibration (Methods 3.4) | `evaluation/snpe_calibration.py` |
| Numpy/JAX engine agreement, gradient-vs-finite-difference (Results 4.1) | `tests/test_jax_engine.py` |

`PAPER_NOTES.md` is the full results ledger this table summarizes: every number in the paper, with
the script that produced it and the date it was last regenerated.

## License

Upon publication, this code will be released under an open-source license permitting free use for
research purposes.
